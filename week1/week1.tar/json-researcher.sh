curl https://learn.zone01oujda.ma/assets/superhero/all.json | jq '.[] | select(.id == 1)' | grep -e name -e '"power"'   
