echo Hello $USERNAME!
