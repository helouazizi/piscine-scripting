wc -l < facts
