cd hard-perm
chmod 401 0 A
chmod 402 1 9
chmod 604 2 8
chmod 777 3
chmod 510 4 7
chmod 460 5 6
