find . -name "a*" -o -name "*z"
